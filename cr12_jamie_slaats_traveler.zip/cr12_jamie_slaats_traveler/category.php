<?php 
/**
* A Simple Category Template
*/
get_header(); ?>

<section id="primary" class="site-content">
	<div class="container" id="content" role="main">
		<div class="row blog-main">
			
			<?php 
// Check if there are any posts to display
			if ( have_posts() ) : ?>
				<header class="archive-header">

					<?php
// Display optional category description and present this in the header section.
					if ( category_description() ) : ?>
						<div class="archive-meta">
							<h1 class="blog-category"><?php
							foreach((get_the_category()) as $category) { 
								echo $category->cat_name . ' '; 
							} ?></h1> <!--This php is then looping through with foreach, getting the category, which is an array and then presenting the current category -->
							<h3 class="lead blog-description"><?php echo category_description(); ?></h3>
						</div>
					<?php endif; ?>
				</header>
				<br>

			</div>
			<div class="row blog-main">

				<div class="col-sm-8 blog-post">
				<?php
// The Loop to display the posts for the sections and categories.
				while(have_posts()) : the_post(); ?><!--while there are posts, show the posts-->
				<div class="blogpostwrapper">
					<div class="row" id="blog-post-title">
						<h3 class="blog-post-title"><a href="<?php the_permalink(); ?>"> <!--retrieves URL for the permalink-->
							<?php the_title(); ?></a></h3><!--retrieves blog title-->
						
					</div>
					<div class="row blog-details">
							<div class="col-sm-6 blog-post-meta">
								<?php
								$timePost = the_time('F jS, Y @ h:i T');
								$cat_Id = get_the_category($post->ID);
								$categories = get_category_parents( $cat_Id[0], TRUE, ' > ' );
								print($timePost.'</div>
									<div class="col-sm-6 blog-post-meta">
									In '.$categories.'</div>');
									?>
					</div>

						<!--MAIN CONTENT OF BLOG SECTION-->	
						<div class="row" id="blog-content">
								<?php the_content(); ?><!--retrieves content-->
						</div>
						<!--/.end of main content blog section-->
						<!--CLOSING META DATA OF BLOG SECTION-->
						<div class="row blog-bottom">
							<div class="col-sm-6 blog-post-bottom-meta">
									<?php echo getPostViews(get_the_ID()); ?> | <?php the_date(); ?> by <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a>
							</div>
							<div class="col-sm-6 blog-post-bottom-meta">
									<?php
									comments_popup_link( 'No comments yet', '1 comment', '% comments', 'comments-link', 'Comments closed');
									?> | <?php echo getPostViews(get_the_ID()); ?> | Words: <?php echo  wcount(); ?>
							</div>
						</div>
					</div>
						<br>
						<br>
						<!--/.end of closing Meta Data Section-->
						<?php endwhile; 
						else: ?>
						<div class="col-sm-8 blog-post">
							<h2>Sorry, no posts matched your criteria.</h2>	

						
						<?php endif; ?>
					</div>

					 <!--BLOG SIDEBAR SECTION -->
					<div class="col-sm-3 col-sm-offset-1 blog-sidebar"> <!--BLOG SIDEBAR SECTION -->
						<div class="sidebar-module-inset">
							<?php if(is_active_sidebar('sidebar')):
								dynamic_sidebar('sidebar');
							endif; ?>
						</div>
					</div>
					<!--/.End of blog sidebarsection-->
			</div>
			<br>
		</section> <!-- /.End of Category Section -->

		<?php get_footer(); ?>