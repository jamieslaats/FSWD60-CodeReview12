<?php get_header(); ?>
<br>
<br>
<div class="container">
  <div class="row blog-main">
  <div class="col-sm-9 blog-post">

    <?php if(have_posts()) :  ?>  <!--if there are any posts-->
     <div class="blogpostwrapper">
    <?php while(have_posts()) : the_post(); ?><!--while there are posts, show the posts-->

    <?php if(has_post_thumbnail()) : ?>
      <?php the_post_thumbnail(); ?>
    <?php endif; ?>

            <div class="row" id="blog-post-title">
              
                <h3 class="blog-post-title"><?php the_title(); ?></h3><!--retrieves blog title-->
            
            </div>
            <div class="row blog-details">
              <div class="col-sm-4 blog-post-meta">
               
                      <?php
                        $timePost = the_time('F jS, Y @ h:i T');
                        $cat_Id = get_the_category($post->ID);
                        $categories = get_category_parents( $cat_Id[0], TRUE, ' > ' );
                        print($timePost.'</div>
                                        <div class="col-sm-4 blog-post-meta">
                                        In '.$categories.'</div>');
            ?>
             
              <div class="col-sm-4 blog-post-meta">
                Posted by: <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a>
              </div>
            </div>
            <br>
        <div class="" id="blog-content">
        <?php the_content(); ?><!--retrieves content-->
          
        </div>
        <?php comments_template(); ?> <!--shows the comments, if there are any -->

        <?php endwhile; ?> <!--end the while loop-->
      </div>
      <br>

        <?php else : ?> <!--if there are no posts-->
        <p><?php__('No Posts Found'); ?></p>
        <?php endif; ?><!--endif-->
  </div><!-- /.blog-post -->
  <div class="col-sm-3 blog-sidebar"> <!--BLOG SIDEBAR SECTION -->
        <div class="sidebar-module-inset">
            <?php if(is_active_sidebar('sidebar')):
                    dynamic_sidebar('sidebar');
                  endif; ?>
        </div>
  </div>
    
  </div>
</div>
<?php get_footer(); ?>