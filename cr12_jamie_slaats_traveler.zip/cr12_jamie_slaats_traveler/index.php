<?php get_header(); ?>
<main>
  <div class="container">
    <div class="row blog-main">

      <div class="col-sm-8 blog-post">

        <?php if(have_posts()) :  ?>  <!--if there are any posts-->
        <?php while(have_posts()) : the_post(); ?><!--while there are posts, show the posts-->
        <div class="blogpostwrapper">


          <div class="row" id="blog-post-title">
            <h3 class="blog-post-title"><a href="<?php the_permalink(); ?>"> <!--retrieves URL for the permalink-->
              <?php the_title(); ?></a></h3><!--retrieves blog title-->
            </div>
            <div class="row blog-details">
              <div class="col-sm-6 blog-post-meta">
                <?php
                $timePost = the_time('F jS, Y @ h:i T');
                $cat_Id = get_the_category($post->ID);
                $categories = get_category_parents( $cat_Id[0], TRUE, ' > ' );
                print($timePost.'</div>
                  <div class="col-sm-6 blog-post-meta">
                  In '.$categories);
                  ?>
                </div>
              </div>
              <div class="row" id="blog-content">

                <?php the_content(); ?><!--retrieves content-->
              </div>
              <div class="row blog-bottom">
                <div class="col-sm-6 blog-post-bottom-meta">
                  Posted by: <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a>
                </div>
                <div class="col-sm-6 blog-post-bottom-meta">
                 <?php
                 comments_popup_link( 'No comments yet', '1 comment', '% comments', 'comments-link', 'Comments closed');
                 ?>  |  <?php echo getPostViews(get_the_ID()); ?>  |  Words: <?php echo  wcount(); ?>
               </div>
             </div>
           </div>  
           <br>
           <br>
           <?php endwhile; ?> <!--end the while loop-->
         </div>

         <?php else : ?> <!--if there are no posts-->
         <h2><?php__('No Posts Found'); ?></h2>
         <?php endif; ?><!--endif-->
         <!-- /.blog-post -->
         <!--BLOG SIDEBAR SECTION -->
        <div class="col-sm-3 col-sm-offset-1 blog-sidebar">
          <div class="sidebar-module-inset">
            <?php if(is_active_sidebar('sidebar')):
              dynamic_sidebar('sidebar');
            endif; ?>
          </div>
        </div> <!--/.end of blog sidebarsection-->
    </div>

  </div><!-- /.container end -->
  <br>
  <br>
</main>
<?php get_footer(); ?>