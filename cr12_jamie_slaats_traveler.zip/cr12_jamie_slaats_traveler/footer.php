<!---FOOTER SECTION BEGINNING --->
    	
    <footer class="blog-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <img class="center-block" src="<?php echo get_template_directory_uri(); ?>/img/mounteverestlogo.png" alt="Mount Everest Travel Blog Logo" width="300">
                </div>
                <div class="col-sm-3">
                    <h3>Contact Address</h3>
                    <p>Hauptstrasse 5 <br>
                        1010 Vienna, Austria <br>
                        <a href="mailto:info@mounteverest.at?subject=feedback">info@mounteverest.at</a></p>
                </div>
                 <div class="col-sm-3">
            			<?php if(is_active_sidebar('footer-sidebar-1')):
              			dynamic_sidebar('footer-sidebar-1');
            			endif; ?>
          		</div>
                <div class="col-sm-3">
                	<h3>Newsletter Signup</h3>
                   <form class="form-group">
                   	<?php es_subbox($namefield = "YES", $desc = "", $group = "Public"); ?>
                   </form>
                </div>
                <div class="row">
                    <div class="col-sm-12 ">
                        <p>Designed by: Jamie Slaats - CodeFactory 2019 &#169;</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--- END OF FOOTER SECTION --->
   <?php wp_footer(); ?>


   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
 </body>
</html>